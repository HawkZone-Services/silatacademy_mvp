import apiClient from "@/lib/apiClient";

const studentExamService = {
  // Get all available exams for student (filtered + locked)
  listAvailable: () => apiClient.get("/exams"),

  // Exams by belt level
  listByBelt: (belt) => apiClient.get(`/exams/belt/${belt}`),

  // Register for exam
  register: (examId) => apiClient.post("/exams/register", { examId }),

  // Get exam details (published only for students)
  getExam: (id) => apiClient.get(`/exams/${id}`),

  // Start attempt (theory)
  startAttempt: (examId) => apiClient.post("/exams/attempt/start", { examId }),

  // Submit theory answers
  submitAttempt: (body) => apiClient.post("/exams/attempt/submit", body),

  // Student’s attempts & final results
  myAttempts: () => apiClient.get("/exams/my-attempts"),

  // Check registration & status
  getRegistrationStatus: (examId) =>
    apiClient.get(`/exams/registration/status/${examId}`),
};

export default studentExamService;
