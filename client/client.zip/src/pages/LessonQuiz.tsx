import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";

import lessonQuizService from "@/services/lessonQuizService";

export default function LessonQuiz() {
  const { lessonId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [quiz, setQuiz] = useState<any>(null);
  const [answers, setAnswers] = useState<any>({});
  const [submitted, setSubmitted] = useState(false);

  const loadQuiz = async () => {
    if (!lessonId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await lessonQuizService.getQuiz(lessonId);
      const data = res?.quiz || res?.data || null;
      setQuiz(data || null);
    } catch (err) {
      console.error("Quiz fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      const res = await lessonQuizService.submitQuiz(lessonId, { answers });
      const data = res?.data || res;

      setSubmitted(true);

      if (data.score !== undefined) {
        alert(`Quiz Completed! Score: ${data.score}%`);
      }

      setTimeout(() => navigate(-1), 1200);
    } catch (err) {
      console.error("Quiz submit error:", err);
      alert("Quiz submission failed.");
    }
  };

  useEffect(() => {
    loadQuiz();
  }, []);

  if (loading) return <div className="p-10 text-center">Loading quiz…</div>;

  if (!quiz) return <div className="p-10 text-center">Quiz not found</div>;

  return (
    <div className="container py-10 space-y-8">
      <h1 className="text-2xl font-bold mb-4">{quiz.title || "Lesson Quiz"}</h1>

      {quiz.questions?.map((q: any, index: number) => (
        <Card key={index} className="mb-4">
          <CardHeader>
            <CardTitle className="text-base flex gap-2">
              Q{index + 1}. {q.question}
            </CardTitle>
          </CardHeader>

          <CardContent>
            {/* MCQ */}
            {q.type === "mcq" && (
              <RadioGroup
                onValueChange={(val) =>
                  setAnswers((prev: any) => ({ ...prev, [q._id]: val }))
                }
              >
                {q.choices.map((choice: string, i: number) => (
                  <div className="flex items-center space-x-2" key={i}>
                    <RadioGroupItem value={choice} />
                    <label>{choice}</label>
                  </div>
                ))}
              </RadioGroup>
            )}

            {/* True / False */}
            {q.type === "truefalse" && (
              <RadioGroup
                onValueChange={(val) =>
                  setAnswers((prev: any) => ({ ...prev, [q._id]: val }))
                }
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="true" />
                  <label>True</label>
                </div>

                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="false" />
                  <label>False</label>
                </div>
              </RadioGroup>
            )}

            {/* Essay */}
            {q.type === "essay" && (
              <Textarea
                className="w-full"
                placeholder="Write your answer..."
                onChange={(e) =>
                  setAnswers((prev: any) => ({
                    ...prev,
                    [q._id]: e.target.value,
                  }))
                }
              />
            )}
          </CardContent>
        </Card>
      ))}

      <Button className="w-full" onClick={handleSubmit} disabled={submitted}>
        Submit Quiz
      </Button>
    </div>
  );
}
