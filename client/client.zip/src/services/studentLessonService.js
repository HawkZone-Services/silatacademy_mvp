import apiClient from "@/lib/apiClient";

const studentLessonService = {
  getAvailable: () => apiClient.get("/lessons/student/available"),

  getProgress: () => apiClient.get("/lessons/student/progress"),
  getMyLessons: () => apiClient.get("/lessons/student/my"),
  getLesson: (lessonId) => apiClient.get(`/lessons/student/${lessonId}`),
  completeLesson: (lessonId, body) =>
    apiClient.post(`/lessons/student/${lessonId}/complete`, body || {}),
};

export default studentLessonService;
