import { CertificateGenerator } from "@/components/CertificateGenerator";
import React from "react";

const Certificates = () => {
  return (
    <div>
      {" "}
      <CertificateGenerator />
    </div>
  );
};

export default Certificates;
