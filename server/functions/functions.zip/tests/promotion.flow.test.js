import request from "supertest";
import app from "../app.js";
import { connectTestDb, clearTestDb, closeTestDb } from "./setup/testDb.js";
import { seedWhiteHappyPath } from "./setup/seedWhiteHappyPath.js";
import { authHeader } from "./setup/authHelper.js";
import Player from "../models/Player.js";

describe("Promotion Flow", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteHappyPath();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("should promote student ONLY if all gates passed", async () => {
    const res = await request(app)
      .post(`/api/belts/${seed.ids.beltHistoryId}/approve`)
      .set(authHeader(seed.tokens.instructorToken));

    expect(res.status).toBe(200);

    const player = await Player.findById(seed.ids.playerId);
    expect(player.beltLevel).toBe("yellow");
  });
});
