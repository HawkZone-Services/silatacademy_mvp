process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "test_secret_key";
process.env.MONGO_TEST_URI || "mongodb://127.0.0.1:27017/silat_test";
