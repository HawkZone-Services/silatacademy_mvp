export default function PlayerProfileV2() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    playerService.getFullProfile().then((res) => {
      if (res.success) setData(res);
    });
  }, []);

  if (!data) return <div>Loading...</div>;

  const { player, stats, attendance, lessons, exams, certificates, timeline } =
    data;

  return (
    <div className="space-y-8">
      {/* HEADER */}
      <Card className="p-6">
        <div className="flex items-center gap-6">
          <div className="h-20 w-20 rounded-full bg-accent" />
          <div>
            <h1 className="text-3xl font-bold">{player.user.name}</h1>
            <p className="text-muted-foreground">{player.user.email}</p>
            <p className="capitalize">{player.beltLevel} Belt</p>
          </div>
        </div>
      </Card>

      {/* STATS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Level" value={stats.level} />
        <Stat label="XP" value={stats.xp} />
        <Stat label="Streak" value={`${stats.streak} days`} />
        <Stat label="Lessons Completed" value={stats.lessonsCompleted} />
      </div>

      {/* TIMELINE */}
      <Timeline items={timeline} />

      {/* CERTIFICATES */}
      <CertificatesList list={certificates} />

      {/* EXAMS */}
      <ExamHistory list={exams} />

      {/* ATTENDANCE */}
      <AttendanceList list={attendance} />
    </div>
  );
}
