const request = require("supertest");
const app = require("../app.js");

const {
  connectTestDb,
  clearTestDb,
  closeTestDb,
} = require("./setup/testDb.js");

const { seedWhiteHappyPath } = require("./setup/seedWhiteHappyPath.js");

const { authHeader } = require("./setup/authHelper.js");

const Player = require("../models/Player.js");

describe("Promotion Flow", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteHappyPath();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("should promote student ONLY if all gates passed", async () => {
    const res = await request(app)
      .post(`/api/belts/${seed.ids.beltHistoryId}/approve`)
      .set(authHeader(seed.tokens.instructorToken));

    expect(res.status).toBe(200);

    const player = await Player.findById(seed.ids.playerId);
    expect(player.beltLevel).toBe("yellow");
  });
});
