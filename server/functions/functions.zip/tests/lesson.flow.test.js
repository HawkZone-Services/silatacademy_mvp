import request from "supertest";
import app from "../app.js";
import { connectTestDb, clearTestDb, closeTestDb } from "./setup/testDb.js";
import { seedWhiteFailPIncomplete } from "./setup/seedWhiteFailPIncomplete.js";
import { authHeader } from "./setup/authHelper.js";

describe("Lesson Flow", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteFailPIncomplete();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("should NOT allow completing lesson if P module incomplete", async () => {
    const res = await request(app)
      .post(`/api/lessons/${seed.ids.examId}/complete`)
      .set(authHeader(seed.tokens.studentToken));

    expect(res.status).toBe(403);
  });
});
