import { useEffect, useState } from "react";
import { useSearchParams, useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import examService from "@/services/examService";

export default function ExamInterface() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { examId } = useParams();

  const [params] = useSearchParams();
  const attemptId = params.get("attempt");

  const token =
    localStorage.getItem("token") || sessionStorage.getItem("token");

  const [exam, setExam] = useState<any>(null);
  const [attempt, setAttempt] = useState<any>(null);
  const [answers, setAnswers] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [focusLosses, setFocusLosses] = useState(0);

  useEffect(() => {
    if (!attemptId || !examId) {
      toast({
        variant: "destructive",
        title: "Invalid attempt",
        description: "You cannot access this exam.",
      });
      navigate("/student-dashboard");
    }
  }, [attemptId, examId]);

  const fetchExam = async () => {
    try {
      const res = await examService.getExam(examId as string);
      if (res?.ok === false) {
        throw new Error(res?.message || "Unable to load exam");
      }
      const payload = res?.exam || res?.data || null;
      if (!payload) {
        throw new Error("Exam not found");
      }
      setExam(payload);
    } catch (err) {
      console.error("Exam fetch error:", err);
    }
  };

  const fetchAttempt = async () => {
    try {
      const res = await examService.getMyAttempts();
      if (res?.ok === false) {
        throw new Error(res?.message || "Unable to load attempts");
      }

      const attempts = res?.attempts || res?.data?.attempts || [];
      const found = attempts.find((a: any) => a._id === attemptId);

      if (!found) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "No active attempt found.",
        });
        navigate("/student-dashboard");
        return;
      }

      if (found.submittedAt) {
        toast({
          variant: "destructive",
          title: "Exam already submitted",
        });
        navigate("/student-dashboard");
      }

      setAttempt(found);
    } catch (err) {
      console.error("Attempt fetch error:", err);
    }
  };

  useEffect(() => {
    const onBlur = () => setFocusLosses((x) => x + 1);
    window.addEventListener("blur", onBlur);

    return () => window.removeEventListener("blur", onBlur);
  }, []);

  useEffect(() => {
    if (!token) return;
    Promise.all([fetchExam(), fetchAttempt()]).finally(() => setLoading(false));
  }, [token]);

  const handleMCQ = (qId: string, index: number) => {
    setAnswers({ ...answers, [qId]: { selectedIndex: index } });
  };

  const handleTrueFalse = (qId: string, value: boolean) => {
    setAnswers({ ...answers, [qId]: { booleanAnswer: value } });
  };

  const handleEssay = (qId: string, text: string) => {
    setAnswers({ ...answers, [qId]: { essayText: text } });
  };

  const handleSubmit = async () => {
    const formattedAnswers = exam.questions.map((q: any) => ({
      questionId: q._id,
      selectedIndex:
        answers[q._id]?.selectedIndex !== undefined
          ? answers[q._id].selectedIndex
          : null,
      booleanAnswer:
        answers[q._id]?.booleanAnswer !== undefined
          ? answers[q._id].booleanAnswer
          : null,
      essayText: answers[q._id]?.essayText || "",
    }));

    try {
      const res = await examService.submitAttempt({
        attemptId,
        answers: formattedAnswers,
        focusLosses,
        forcedSubmitReason: null,
      });

      if (res?.ok === false) {
        toast({
          variant: "destructive",
          title: "Submit failed",
          description: res.message || "An error occurred.",
        });
        return;
      }

      localStorage.setItem("refreshResults", "1");

      toast({
        title: "Exam submitted",
        description: "Your theory exam has been submitted successfully.",
      });

      navigate("/student-dashboard");
    } catch (err) {
      console.error("Submit error:", err);
    }
  };

  if (loading || !exam) {
    return (
      <div className="flex items-center justify-center h-screen">
        <span>Loading exam...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <Card className="mx-auto max-w-3xl shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            {exam.title}
          </CardTitle>
          <div className="text-center text-muted-foreground">
            {exam.questions.length} Questions • {exam.timeLimit} Minutes
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {exam.questions.map((q: any, index: number) => (
            <div key={q._id} className="p-4 rounded-lg border bg-card/40">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">
                  Q{index + 1}. {q.text || q.question}
                </h3>
                <Badge variant="outline" className="capitalize">
                  {q.type}
                </Badge>
              </div>

              {q.type === "mcq" && (
                <RadioGroup onValueChange={(v) => handleMCQ(q._id, Number(v))}>
                  {q.choices.map((choice: string, i: number) => (
                    <div key={i} className="flex items-center space-x-2">
                      <RadioGroupItem value={String(i)} id={`${q._id}-${i}`} />
                      <label htmlFor={`${q._id}-${i}`}>{choice}</label>
                    </div>
                  ))}
                </RadioGroup>
              )}

              {q.type === "truefalse" && (
                <div className="space-x-4">
                  <Button
                    variant={
                      answers[q._id]?.booleanAnswer === true
                        ? "default"
                        : "outline"
                    }
                    onClick={() => handleTrueFalse(q._id, true)}
                  >
                    True
                  </Button>

                  <Button
                    variant={
                      answers[q._id]?.booleanAnswer === false
                        ? "default"
                        : "outline"
                    }
                    onClick={() => handleTrueFalse(q._id, false)}
                  >
                    False
                  </Button>
                </div>
              )}

              {q.type === "essay" && (
                <Textarea
                  placeholder="Write your answer..."
                  onChange={(e) => handleEssay(q._id, e.target.value)}
                />
              )}
            </div>
          ))}

          <Button className="w-full py-6 text-lg" onClick={handleSubmit}>
            Submit Exam
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
