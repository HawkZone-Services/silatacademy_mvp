import apiClient from "@/lib/apiClient";

const eligibilityService = {
  get: () => apiClient.get("/student/eligibility"),
};

export default eligibilityService;
