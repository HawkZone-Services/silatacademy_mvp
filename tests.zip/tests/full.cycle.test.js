const request = require("supertest");
const app = require("../app.js");

const {
  connectTestDb,
  clearTestDb,
  closeTestDb,
} = require("./setup/testDb.js");

const { seedWhiteHappyPath } = require("./setup/seedWhiteHappyPath.js");

const { authHeader } = require("./setup/authHelper.js");

const Player = require("../models/Player.js");

describe("FULL BACKEND CYCLE", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteHappyPath();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("Student completes exam → Coach approves → Player promoted", async () => {
    // start attempt
    const attemptRes = await request(app)
      .post("/api/exams/attempt/start")
      .set(authHeader(seed.tokens.studentToken))
      .send({ examId: seed.ids.examId });

    expect(attemptRes.status).toBe(200);

    // approve belt
    const approveRes = await request(app)
      .post(`/api/belts/${seed.ids.beltHistoryId}/approve`)
      .set(authHeader(seed.tokens.instructorToken));

    expect(approveRes.status).toBe(200);

    const player = await Player.findById(seed.ids.playerId);
    expect(player.beltLevel).toBe("yellow");
  });
});
