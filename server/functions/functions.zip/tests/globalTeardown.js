import mongoose from "mongoose";

export default async function globalTeardown() {
  try {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.dropDatabase();
      await mongoose.disconnect();
      console.log("🧹 Test DB dropped & disconnected");
    }
  } catch (err) {
    console.error("❌ Error during globalTeardown", err);
  }
}
