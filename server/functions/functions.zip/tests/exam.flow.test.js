import request from "supertest";
import app from "../app.js";
import { connectTestDb, clearTestDb, closeTestDb } from "./setup/testDb.js";
import { seedWhiteFailPIncomplete } from "./setup/seedWhiteFailPIncomplete.js";
import { seedWhiteFailAttendance } from "./setup/seedWhiteFailAttendance.js";
import { seedWhiteHappyPath } from "./setup/seedWhiteHappyPath.js";
import { authHeader } from "./setup/authHelper.js";

describe("Exam startAttempt Flow", () => {
  afterEach(async () => {
    await clearTestDb();
  });

  afterAll(async () => {
    await closeTestDb();
  });

  it("should BLOCK exam startAttempt if P module incomplete", async () => {
    await connectTestDb();
    const seed = await seedWhiteFailPIncomplete();

    const res = await request(app)
      .post("/api/exams/attempt/start")
      .set(authHeader(seed.tokens.studentToken))
      .send({ examId: seed.ids.examId });

    expect(res.status).toBe(403);
    expect(res.body.message).toMatch(/not eligible/i);
  });

  it("should BLOCK exam startAttempt if attendance insufficient", async () => {
    await connectTestDb();
    const seed = await seedWhiteFailAttendance();

    const res = await request(app)
      .post("/api/exams/attempt/start")
      .set(authHeader(seed.tokens.studentToken))
      .send({ examId: seed.ids.examId });

    expect(res.status).toBe(403);
    expect(res.body.message).toMatch(/attendance/i);
  });

  it("should ALLOW exam startAttempt if all gates pass", async () => {
    await connectTestDb();
    const seed = await seedWhiteHappyPath();

    const res = await request(app)
      .post("/api/exams/attempt/start")
      .set(authHeader(seed.tokens.studentToken))
      .send({ examId: seed.ids.examId });

    expect(res.status).toBe(200);
    expect(res.body.data.attemptId).toBeDefined();
  });
});
