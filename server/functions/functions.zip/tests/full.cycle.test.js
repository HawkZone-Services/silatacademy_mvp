import request from "supertest";
import app from "../app.js";
import { connectTestDb, clearTestDb, closeTestDb } from "./setup/testDb.js";
import { seedWhiteHappyPath } from "./setup/seedWhiteHappyPath.js";
import { authHeader } from "./setup/authHelper.js";
import Player from "../models/Player.js";

describe("FULL BACKEND CYCLE", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteHappyPath();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("Student completes exam → Coach approves → Player promoted", async () => {
    // start attempt
    const attemptRes = await request(app)
      .post("/api/exams/attempt/start")
      .set(authHeader(seed.tokens.studentToken))
      .send({ examId: seed.ids.examId });

    expect(attemptRes.status).toBe(200);

    // approve belt
    const approveRes = await request(app)
      .post(`/api/belts/${seed.ids.beltHistoryId}/approve`)
      .set(authHeader(seed.tokens.instructorToken));

    expect(approveRes.status).toBe(200);

    const player = await Player.findById(seed.ids.playerId);
    expect(player.beltLevel).toBe("yellow");
  });
});
