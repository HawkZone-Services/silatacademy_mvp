import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Lock, PlayCircle } from "lucide-react";

import studentLessonService from "@/services/studentLessonService";

export default function StudentLessonView() {
  const { lessonId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [lesson, setLesson] = useState<any>(null);

  // Normalizer
  const normalizeLesson = (raw: any) => {
    return {
      _id: raw._id,
      title: raw.title,
      content: raw.content || "",
      videoUrl: raw.videoUrl || "",
      resources: raw.resources || [],
      locked: raw.locked || false,
      completed: raw.completed || false,
      quizAvailable: raw.quizAvailable || false,
      requiredAttendance: raw.requiredAttendance ?? null,
      myAttendance: raw.myAttendance ?? null,
    };
  };

  const loadLesson = async () => {
    if (!lessonId) {
      setLoading(false);
      return;
    }
    setLoading(true);

    try {
      const res = await studentLessonService.getLesson(lessonId);
      const payload = res?.lesson || res?.data || null;
      const normalized = normalizeLesson(payload || {});

      setLesson(normalized);
    } catch (err) {
      console.error("Lesson fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  const markLessonComplete = async () => {
    try {
      await studentLessonService.completeLesson(lessonId);
      loadLesson();
    } catch (err) {
      console.error("Lesson complete error:", err);
    }
  };

  useEffect(() => {
    loadLesson();
  }, []);

  if (loading) return <div className="p-10 text-center">Loading lesson…</div>;

  if (!lesson) return <div className="p-10 text-center">Lesson not found</div>;

  return (
    <div className="container py-10 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold flex gap-2">
          {lesson.title}
          {lesson.locked && <Badge className="bg-gray-600">Locked</Badge>}
          {lesson.completed && (
            <Badge className="bg-green-600">Completed</Badge>
          )}
        </h1>

        <Button variant="outline" onClick={() => navigate(-1)}>
          Back
        </Button>
      </div>

      {/* Attendance Gate */}
      {lesson.requiredAttendance !== null && (
        <div className="text-sm text-muted-foreground">
          Attendance Required:{" "}
          <strong>
            {lesson.myAttendance}/{lesson.requiredAttendance}
          </strong>
        </div>
      )}

      {lesson.locked && (
        <Card className="border-red-400 bg-red-100/20">
          <CardContent className="py-6">
            <p className="text-red-600 font-medium flex gap-2 items-center">
              <Lock className="h-5 w-5" />
              You must complete required attendance or previous lessons.
            </p>
          </CardContent>
        </Card>
      )}

      {!lesson.locked && (
        <>
          {/* VIDEO */}
          {lesson.videoUrl && (
            <div className="rounded-lg overflow-hidden shadow">
              <iframe
                src={lesson.videoUrl}
                className="w-full h-[350px] rounded"
              />
            </div>
          )}

          {/* CONTENT */}
          <Card>
            <CardHeader>
              <CardTitle>Lesson Content</CardTitle>
            </CardHeader>
            <CardContent>
              <div
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: lesson.content }}
              />
            </CardContent>
          </Card>

          {/* RESOURCES */}
          {lesson.resources?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {lesson.resources.map((r: any, idx: number) => (
                  <a
                    key={idx}
                    href={r.url}
                    target="_blank"
                    className="text-blue-600 underline"
                  >
                    {r.title}
                  </a>
                ))}
              </CardContent>
            </Card>
          )}

          {/* ACTIONS */}
          <div className="flex gap-3">
            {!lesson.completed && (
              <Button onClick={markLessonComplete}>
                <CheckCircle className="h-4 w-4 mr-1" />
                Mark as Completed
              </Button>
            )}

            {lesson.quizAvailable && (
              <Button
                variant={lesson.completed ? "default" : "secondary"}
                onClick={() => navigate(`/student/lessons/${lesson._id}/quiz`)}
              >
                <PlayCircle className="h-4 w-4 mr-1" />
                Start Quiz
              </Button>
            )}
          </div>
        </>
      )}
    </div>
  );
}
