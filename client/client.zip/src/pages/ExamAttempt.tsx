import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import studentExamService from "@/services/studentExamService";

import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, Timer } from "lucide-react";

export default function ExamAttempt() {
  const { attemptId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [exam, setExam] = useState(null);
  const [answers, setAnswers] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);

  const [focusLosses, setFocusLosses] = useState(0);
  const [forcedSubmit, setForcedSubmit] = useState(false);

  const timerRef = useRef(null);

  // ============================
  // Load exam data
  // ============================
  const loadAttempt = async () => {
    try {
      const res = await studentExamService.getExam(attemptId);
      const data = await res.json();

      if (!data?.exam) {
        navigate("/student");
        return;
      }

      setExam(data.exam);
      setTimeLeft(data.exam.timeLimit * 60); // minutes → seconds
    } catch (err) {
      console.error("Attempt load error:", err);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadAttempt();
  }, [attemptId]);

  // ============================
  // TIMER
  // ============================
  useEffect(() => {
    if (!timeLeft || forcedSubmit) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          handleSubmit(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [timeLeft, forcedSubmit]);

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  // ============================
  // ANTI-CHEAT
  // ============================
  useEffect(() => {
    const onBlur = () => setFocusLosses((x) => x + 1);

    window.addEventListener("blur", onBlur);
    return () => window.removeEventListener("blur", onBlur);
  }, []);

  // ============================
  // Update answers
  // ============================
  const updateAnswer = (qid, value) => {
    setAnswers((prev) => ({
      ...prev,
      [qid]: value,
    }));
  };

  // ============================
  // SUBMIT ATTEMPT
  // ============================
  const handleSubmit = async (autoForced = false) => {
    if (!exam) return;

    setForcedSubmit(autoForced);

    const formatted = exam.questions.map((q) => ({
      questionId: q._id,
      selectedIndex: q.type === "mcq" ? answers[q._id] ?? null : null,
      booleanAnswer: q.type === "truefalse" ? answers[q._id] ?? null : null,
      essayText: q.type === "essay" ? answers[q._id] ?? "" : "",
    }));

    const body = {
      attemptId,
      answers: formatted,
      focusLosses,
      forcedSubmitReason: autoForced ? "TIME_EXPIRED" : null,
    };

    try {
      const res = await studentExamService.submitAttempt(body);
      const data = await res.json();

      if (data.success) {
        navigate("/student/exams/results");
      }
    } catch (err) {
      console.error("Submit error:", err);
    }
  };

  // ============================
  // UI RENDER
  // ============================
  if (loading || !exam) return <p>Loading exam...</p>;

  return (
    <div className="container py-10">
      <Card className="shadow-card border-border/40">
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>{exam.title}</span>

            <div className="flex items-center gap-2 text-secondary">
              <Timer size={18} />
              <strong>{formatTime(timeLeft)}</strong>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent>
          <div className="space-y-6">
            <p className="text-muted-foreground">
              Answer all questions carefully.
            </p>

            <Progress
              value={
                (Object.keys(answers).length / exam.questions.length) * 100
              }
            />

            {exam.questions.map((q, idx) => (
              <div
                key={q._id}
                className="p-5 border rounded-lg bg-accent/10 space-y-3"
              >
                <h3 className="font-semibold">
                  {idx + 1}. {q.text}
                </h3>

                {/* =======================
                    MCQ
                ======================= */}
                {q.type === "mcq" && (
                  <div className="space-y-2">
                    {q.choices.map((choice, cIdx) => (
                      <label
                        key={cIdx}
                        className="flex items-center gap-2 cursor-pointer"
                      >
                        <input
                          type="radio"
                          checked={answers[q._id] === cIdx}
                          onChange={() => updateAnswer(q._id, cIdx)}
                        />
                        {choice}
                      </label>
                    ))}
                  </div>
                )}

                {/* =======================
                    TRUE / FALSE
                ======================= */}
                {q.type === "truefalse" && (
                  <div className="flex gap-6">
                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={answers[q._id] === true}
                        onChange={() => updateAnswer(q._id, true)}
                      />
                      True
                    </label>

                    <label className="flex items-center gap-2">
                      <input
                        type="radio"
                        checked={answers[q._id] === false}
                        onChange={() => updateAnswer(q._id, false)}
                      />
                      False
                    </label>
                  </div>
                )}

                {/* =======================
                    ESSAY
                ======================= */}
                {q.type === "essay" && (
                  <textarea
                    className="w-full border p-2 rounded"
                    rows={4}
                    placeholder="Write your answer..."
                    value={answers[q._id] || ""}
                    onChange={(e) => updateAnswer(q._id, e.target.value)}
                  />
                )}
              </div>
            ))}

            <div className="pt-4">
              <Button
                className="w-full"
                size="lg"
                onClick={() => handleSubmit(false)}
              >
                Submit Answers
              </Button>

              {focusLosses > 3 && (
                <p className="text-red-600 mt-3 flex items-center gap-1">
                  <AlertCircle size={14} />
                  Warning: You switched tabs {focusLosses} times!
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
