import dotenv from "dotenv";
import mongoose from "mongoose";

// تحميل env الخاصة بالاختبارات
dotenv.config({ path: ".env.test" });

export default async function globalSetup() {
  // تأكد إننا في test mode
  process.env.NODE_ENV = "test";

  // لو Jest اشتغل قبل ما DB تتوصل
  if (mongoose.connection.readyState === 1) {
    return;
  }

  const mongoUri = process.env.MONGO_URI_TEST || process.env.MONGO_URI;

  if (!mongoUri) {
    throw new Error("❌ MONGO_URI_TEST is not defined");
  }

  await mongoose.connect(mongoUri, {
    dbName: process.env.DB_NAME || "silatacademy_test",
  });

  console.log("🧪 Test DB connected");
}
