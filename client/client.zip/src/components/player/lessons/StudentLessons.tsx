import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Lock, BookOpen, CheckCircle } from "lucide-react";

import studentLessonService from "@/services/studentLessonService";

export default function StudentLessons({ onStartQuiz }) {
  const [loading, setLoading] = useState(true);
  const [lessons, setLessons] = useState([]);
  const [attendance, setAttendance] = useState({
    total: 0,
    present: 0,
    ratio: 0,
  });

  const fetchLessons = async () => {
    setLoading(true);
    try {
      const res = await studentLessonService.getAvailable();
      const data = await res.json();

      setLessons(data.items || []);
      setAttendance(data.attendance || {});
    } catch (e) {
      console.error("Fetch lessons error:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLessons();
  }, []);

  if (loading) return <p>Loading lessons...</p>;

  return (
    <div className="space-y-8">
      {/* Attendance Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Summary</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          Total Sessions: {attendance.total} <br />
          Present: {attendance.present} <br />
          Attendance Rate: {attendance.ratio}%
        </CardContent>
      </Card>

      {/* Lessons List */}
      <Card>
        <CardHeader>
          <CardTitle>Your Lessons</CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {lessons.map((l) => (
            <div
              key={l._id}
              className="p-4 border rounded-lg flex items-center justify-between bg-accent/10"
            >
              <div>
                <h3 className="font-semibold">{l.title}</h3>
                <p className="text-sm text-muted-foreground">{l.description}</p>

                {l.completed && (
                  <Badge className="mt-2 flex gap-1">
                    <CheckCircle className="w-4 h-4 text-green-500" /> Completed
                  </Badge>
                )}

                {l.lockedReason && (
                  <Badge variant="destructive" className="mt-2 flex gap-1">
                    <Lock className="w-4 h-4" /> Locked: {l.lockedReason}
                  </Badge>
                )}
              </div>

              <div>
                {l.canStart ? (
                  <Button
                    variant={l.completed ? "outline" : "default"}
                    onClick={() => onStartQuiz(l)}
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    {l.completed ? "Review Lesson" : "Start Lesson"}
                  </Button>
                ) : (
                  <Button disabled variant="secondary">
                    <Lock className="w-4 h-4 mr-2" /> Locked
                  </Button>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
