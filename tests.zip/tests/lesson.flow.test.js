const request = require("supertest");
const app = require("../app.js");

const {
  connectTestDb,
  clearTestDb,
  closeTestDb,
} = require("./setup/testDb.js");

const {
  seedWhiteFailPIncomplete,
} = require("./setup/seedWhiteFailPIncomplete.js");

const { authHeader } = require("./setup/authHelper.js");

describe("Lesson Flow", () => {
  let seed;

  beforeAll(async () => {
    await connectTestDb();
    seed = await seedWhiteFailPIncomplete();
  });

  afterAll(async () => {
    await clearTestDb();
    await closeTestDb();
  });

  it("should NOT allow completing lesson if P module incomplete", async () => {
    const res = await request(app)
      .post(`/api/lessons/${seed.ids.examId}/complete`)
      .set(authHeader(seed.tokens.studentToken));

    expect(res.status).toBe(403);
  });
});
