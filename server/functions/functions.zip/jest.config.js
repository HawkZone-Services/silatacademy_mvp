export default {
  testEnvironment: "node",

  // root = server/functions
  rootDir: ".",

  testMatch: ["<rootDir>/server/functions/tests/**/*.test.js"],

  moduleFileExtensions: ["js", "json"],

  clearMocks: true,
  resetMocks: true,
  restoreMocks: true,

  testTimeout: 30000,

  globalSetup: "<rootDir>/server/functions/tests/globalSetup.js",
  globalTeardown: "<rootDir>/server/functions/tests/globalTeardown.js",
};
