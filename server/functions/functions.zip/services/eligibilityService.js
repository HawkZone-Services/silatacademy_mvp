import Attendance from "../models/Attendance.js";
import Lesson from "../models/Lesson.js";
import LessonProgress from "../models/LessonProgress.js";
import Program from "../models/Program.js";
import Player from "../models/Player.js";
import ExamRegistration from "../models/ExamRegistration.js";
import { toObjectId } from "../utils/validation.js";
import Exam from "../models/Exam.js";
import ExamAttempt from "../models/ExamAttempt.js";

/* =========================
   HELPERS
========================= */
export const beltToProgramLevel = (belt) => {
  if (["white", "yellow"].includes(belt)) return "beginner";
  if (["blue", "brown"].includes(belt)) return "intermediate";
  if (["red", "black"].includes(belt)) return "advanced";
  return null;
};

export const getPlayerForUser = async (userId) => {
  if (!userId) return null;
  return Player.findOne({ user: userId });
};

export const getAttendanceSummary = async (playerId) => {
  if (!playerId) return { total: 0, present: 0, ratio: 0 };

  const [total, present] = await Promise.all([
    Attendance.countDocuments({ player: playerId }),
    Attendance.countDocuments({ player: playerId, status: "present" }),
  ]);

  const ratio = total > 0 ? Math.round((present / total) * 100) : 0;
  return { total, present, ratio };
};

export const hasMinimumAttendance = (summary) => {
  if (!summary.total) return true;
  return summary.ratio >= 50;
};

export const lessonCompletionForBelt = async (userId, beltLevel) => {
  const level = beltToProgramLevel(beltLevel);
  if (!level) return { total: 0, completed: 0 };

  const [totalLessons] = await Lesson.aggregate([
    {
      $lookup: {
        from: Program.collection.name,
        localField: "program",
        foreignField: "_id",
        as: "program",
      },
    },
    { $unwind: { path: "$program", preserveNullAndEmptyArrays: true } },
    { $match: { "program.level": level } },
    { $count: "count" },
  ]);

  const [completedLessons] = await LessonProgress.aggregate([
    { $match: { user: toObjectId(userId), completed: true } },
    {
      $lookup: {
        from: Lesson.collection.name,
        localField: "lesson",
        foreignField: "_id",
        as: "lesson",
      },
    },
    { $unwind: { path: "$lesson", preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: Program.collection.name,
        localField: "lesson.program",
        foreignField: "_id",
        as: "program",
      },
    },
    { $unwind: { path: "$program", preserveNullAndEmptyArrays: true } },
    { $match: { "program.level": level } },
    { $count: "count" },
  ]);

  return {
    total: totalLessons?.count || 0,
    completed: completedLessons?.count || 0,
  };
};
/* =========================
   CORE ELIGIBILITY (PATCHED)
========================= */

export const buildExamEligibility = async ({ exam, userId, registration }) => {
  const player = await getPlayerForUser(userId);
  const attendanceSummary = await getAttendanceSummary(player?._id);
  const attendanceOK = hasMinimumAttendance(attendanceSummary);

  const lessonStatus = await lessonCompletionForBelt(userId, exam?.beltLevel);

  const lockedReasons = [];

  if (lessonStatus.total > 0 && lessonStatus.completed < lessonStatus.total) {
    lockedReasons.push("COMPLETE_REQUIRED_LESSONS");
  }

  if (!attendanceOK) {
    lockedReasons.push("INSUFFICIENT_ATTENDANCE");
  }

  const locked = lockedReasons.length > 0;
  const lockedReason = lockedReasons[0] || null;

  return {
    locked,
    isEligible: !locked,
    lockedReason,
    reasonIfNotEligible: lockedReason,
    lockedReasons,
    lessonsRequired: lessonStatus.total,
    lessonsCompleted: lessonStatus.completed,
    registrationStatus: registration?.status || null,
  };
};

export const attachExamEligibility = async (exams = [], userId) => {
  const normalized = exams.map((exam) =>
    exam?.toObject ? { ...exam.toObject(), _id: exam._id } : exam
  );

  const player = await Player.findOne({ user: userId }).lean();

  const [registrations, attempts] = await Promise.all([
    player ? ExamRegistration.find({ player: player._id }).lean() : [],
    ExamAttempt.find({ student: userId }).lean(),
  ]);

  const regMap = new Map(registrations.map((r) => [r.exam.toString(), r]));

  const attemptMap = new Map(attempts.map((a) => [a.exam.toString(), a]));

  return Promise.all(
    normalized.map(async (exam) => {
      const registration = regMap.get(exam._id.toString());
      const attempt = attemptMap.get(exam._id.toString());

      let registrationStatus = registration?.status || null;
      let examCompleted = false;

      // 🔥 لو الامتحان اتبعت خلاص
      if (attempt?.submittedAt) {
        registrationStatus = "completed";
        examCompleted = true;
      }

      const eligibility = await buildExamEligibility({
        exam,
        userId,
        registration,
      });

      return {
        ...exam,
        ...eligibility,
        registrationStatus,
        examCompleted,
        attemptId: attempt?._id || null,
      };
    })
  );
};

export const mapLessonEligibility = (
  lesson,
  { progressMap = new Map(), prereqSet = new Set(), attendanceOK = true } = {}
) => {
  const progress = progressMap.get(lesson._id.toString());
  const completed = Boolean(progress?.completed);
  const quizScore = progress?.quizScore ?? null;
  const attempts = progress?.attempts ?? 0;

  const hasPrereq =
    lesson.prerequisiteLesson &&
    prereqSet.has(lesson.prerequisiteLesson.toString());

  const lockedReasons = [];

  if (lesson.prerequisiteLesson && !hasPrereq) {
    lockedReasons.push("PREREQUISITE_NOT_COMPLETED");
  }

  if (!attendanceOK) {
    lockedReasons.push("INSUFFICIENT_ATTENDANCE");
  }

  const lockedReason = lockedReasons[0] || null;
  const locked = lockedReasons.length > 0;

  return {
    _id: lesson._id,
    title: lesson.title,
    description: lesson.description,
    program: lesson.program,
    module: lesson.module,
    order: lesson.order || 0,
    level: lesson.level || lesson.beltLevel || null,
    type: lesson.type || "theory",
    videoUrl: lesson.videoUrl,
    resources: lesson.resources || [],
    completed,
    quizScore,
    attempts,
    locked,
    lockedReason,
    reasonIfNotEligible: lockedReason,
    isEligible: !locked,
    canStart: !locked,
  };
};

export const getRegistrationForExam = async (examId, userId) => {
  const examObj = toObjectId(examId);
  const playerObj = toObjectId(userId);
  if (!examObj || !playerObj) return null;
  return ExamRegistration.findOne({ exam: examObj, player: playerObj });
};

export const getStudentEligibility = async ({ userId, beltLevel }) => {
  /* ======================
     BELT CONFIG
  ====================== */
  const belt = await BeltRanking.findOne({ level: beltLevel });
  if (!belt) {
    return null;
  }

  /* ======================
     ATTENDANCE
  ====================== */
  const totalSessions = await Attendance.countDocuments({ player: userId });
  const attendedSessions = await Attendance.countDocuments({
    player: userId,
    status: "present",
  });

  const attendanceRate =
    totalSessions > 0
      ? Math.round((attendedSessions / totalSessions) * 100)
      : 0;

  const attendancePassed =
    attendedSessions >= belt.attendance.requiredSessions &&
    attendanceRate >= belt.attendance.minRate;

  /* ======================
     LESSONS
  ====================== */
  const lessons = await Lesson.find({ isActive: true }).select("_id");

  const progresses = await LessonProgress.find({
    user: userId,
    completed: true,
  });

  const completedLessons = progresses.length;

  const unlockedLessons = Math.min(
    belt.lessons.totalLessons,
    Math.floor(attendedSessions / belt.lessons.unlockEvery) *
      belt.lessons.unlockEvery
  );

  const lessonsPassed = completedLessons >= belt.lessons.totalLessons;

  /* ======================
     EXAM
  ====================== */
  const exam = await Exam.findOne({
    beltLevel,
    isActive: true,
  });

  let examStatus = "locked";
  let canRegister = false;
  let canStart = false;
  let attemptId = null;

  if (attendancePassed && lessonsPassed && exam) {
    const registration = await ExamRegistration.findOne({
      user: userId,
      exam: exam._id,
    });

    if (!registration) {
      examStatus = "register";
      canRegister = true;
    } else if (registration.status === "pending") {
      examStatus = "pending";
    } else if (registration.status === "approved") {
      examStatus = "approved";
      canStart = true;
    }

    const attempt = await ExamAttempt.findOne({
      user: userId,
      exam: exam._id,
    });

    if (attempt) {
      examStatus = attempt.status === "passed" ? "completed" : attempt.status;
      attemptId = attempt._id;
    }
  }

  /* ======================
     FINAL
  ====================== */
  return {
    attendance: {
      attendedSessions,
      requiredSessions: belt.attendance.requiredSessions,
      rate: attendanceRate,
      minRate: belt.attendance.minRate,
      passed: attendancePassed,
    },

    lessons: {
      total: belt.lessons.totalLessons,
      completed: completedLessons,
      unlocked: unlockedLessons,
      passed: lessonsPassed,
    },

    exam: {
      examId: exam?._id || null,
      status: examStatus,
      canRegister,
      canStart,
      attemptId,
    },

    eligibleForBelt:
      attendancePassed && lessonsPassed && examStatus === "completed",
  };
};
