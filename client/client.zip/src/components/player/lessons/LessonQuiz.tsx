import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import studentLessonService from "@/services/studentLessonService";

export default function LessonQuiz({ lesson, onFinish }) {
  const [score, setScore] = useState(0);
  const [step, setStep] = useState("quiz"); // quiz or done

  const questions = [
    { id: 1, q: "Did you understand the technique?", score: 10 },
    { id: 2, q: "Can you demonstrate the movement?", score: 10 },
  ];

  const handleComplete = async () => {
    await studentLessonService.completeLesson(lesson._id, {
      quizScore: score,
      quizMax: 20,
      passed: score >= 10,
    });

    setStep("done");
    onFinish();
  };

  if (step === "done") {
    return (
      <Card className="p-6 text-center">
        <CardTitle className="mb-4">Lesson Completed!</CardTitle>
        <p className="text-muted-foreground mb-3">Your score: {score}/20</p>
        <Button onClick={onFinish}>Back</Button>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lesson Quiz — {lesson.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {questions.map((q) => (
          <div key={q.id} className="border p-4 rounded-lg">
            <p>{q.q}</p>
            <Button
              className="mt-2"
              onClick={() => setScore((prev) => prev + q.score)}
            >
              I Understand
            </Button>
          </div>
        ))}

        <Button className="w-full" onClick={handleComplete}>
          Submit Quiz
        </Button>
      </CardContent>
    </Card>
  );
}
